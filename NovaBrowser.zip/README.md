# Nova Tarayıcı

WebView tabanlı Android tarayıcı + Gemini / Groq AI asistanı.

- Sekmeler, gizli sekme, geçmiş, yer imleri, indirmeler, masaüstü sitesi, sayfada bul,
  okuma modu, çeviri, yazdır/PDF, ana ekrana ekle, tam ekran video
- Tema: Sistem / Siyah / Beyaz
- AI: Ayarlar > AI Asistan bölümünden API anahtarı gir, modeli listeden seç
- Sağ altta sürüklenebilir ✨ AI düğmesi
- Ana ekran widget'ları: Arama çubuğu, AI, Kısayollar
