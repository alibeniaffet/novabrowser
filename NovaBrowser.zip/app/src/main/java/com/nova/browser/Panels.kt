package com.nova.browser

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlin.math.abs

// ====================================================================== ortak sayfa iskeleti

fun MainActivity.lpm(top: Int = 8): LinearLayout.LayoutParams {
    val lp = LinearLayout.LayoutParams(MP, WC)
    lp.topMargin = dp(top)
    return lp
}

fun MainActivity.showPage(
    title: String,
    rightLabel: String? = null,
    rightAction: (() -> Unit)? = null,
    build: LinearLayout.() -> Unit
) {
    overlay.removeAllViews()
    val page = LinearLayout(this)
    page.orientation = LinearLayout.VERTICAL

    val head = LinearLayout(this)
    head.orientation = LinearLayout.HORIZONTAL
    head.gravity = Gravity.CENTER_VERTICAL
    head.setPadding(dp(4), dp(6), dp(8), dp(6))
    head.addView(iconBtn("←", 22f) { closeOverlay() })
    head.addView(tv(title, 19f, P.text, true), LinearLayout.LayoutParams(0, WC, 1f))
    if (rightLabel != null && rightAction != null) head.addView(iconBtn(rightLabel, 20f) { rightAction() })
    page.addView(head)
    page.addView(divider())

    val sv = ScrollView(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(8), dp(16), dp(32))
    col.build()
    sv.addView(col, ViewGroup.LayoutParams(MP, WC))
    page.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))

    overlay.addView(page, FrameLayout.LayoutParams(MP, MP))
    overlay.visibility = View.VISIBLE
    hideKeyboard()
}

fun MainActivity.closeOverlay() {
    if (overlay.visibility != View.VISIBLE) return
    overlay.removeAllViews()
    overlay.visibility = View.GONE
    applySettingsAll()
    val t = cur
    if (t != null && t.isStart) applyStart(t)
    refreshNav()
}

fun MainActivity.choose(title: String, labels: List<String>, checked: Int, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setSingleChoiceItems(labels.toTypedArray(), checked) { dlg, which ->
            dlg.dismiss()
            onPick(which)
        }
        .setNegativeButton("İptal", null)
        .show()
}

fun MainActivity.inputDialog(title: String, current: String, hint: String, secret: Boolean = false, onOk: (String) -> Unit) {
    val input = EditText(this)
    input.setText(current)
    input.hint = hint
    input.setSingleLine()
    if (secret) input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    val box = FrameLayout(this)
    box.setPadding(dp(20), dp(8), dp(20), 0)
    box.addView(input)
    AlertDialog.Builder(this)
        .setTitle(title)
        .setView(box)
        .setPositiveButton("Tamam") { _, _ -> onOk(input.text.toString().trim()) }
        .setNegativeButton("İptal", null)
        .show()
}

// ====================================================================== sekmeler

fun MainActivity.showTabs() {
    showPage("Sekmeler (${tabs.size})", "＋", {
        closeOverlay()
        newTab(null, false)
        focusOmni()
    }) {
        val row = LinearLayout(this@showTabs)
        row.orientation = LinearLayout.HORIZONTAL
        val a = pill("＋ Yeni sekme", P.accent, Color.WHITE) {
            closeOverlay()
            newTab(null, false)
            focusOmni()
        }
        val b = pill("🕶 Gizli sekme") {
            closeOverlay()
            newTab(null, true)
        }
        val lpB = LinearLayout.LayoutParams(WC, WC)
        lpB.leftMargin = dp(8)
        row.addView(a)
        row.addView(b, lpB)
        addView(row, lpm(8))

        for (t in tabs.toList()) {
            val c = LinearLayout(this@showTabs)
            c.orientation = LinearLayout.HORIZONTAL
            c.gravity = Gravity.CENTER_VERTICAL
            c.background = rounded(if (t === cur) 0x333B82F6 else P.card, 14)
            c.setPadding(dp(14), dp(8), dp(4), dp(8))

            val info = LinearLayout(this@showTabs)
            info.orientation = LinearLayout.VERTICAL
            val name = if (t.isStart) "Yeni sekme" else t.title.ifBlank { t.url }
            val t1 = tv((if (t.incognito) "🕶 " else "") + name, 15f, P.text, true)
            t1.ellipsize1()
            val sub = if (t.isStart) "Başlangıç sayfası" else (Uri.parse(t.url).host ?: t.url)
            val t2 = tv(sub, 12f, P.sub)
            t2.ellipsize1()
            info.addView(t1)
            info.addView(t2)
            c.addView(info, LinearLayout.LayoutParams(0, WC, 1f))
            c.addView(iconBtn("✕", 18f) {
                closeTab(t)
                showTabs()
            })
            c.setOnClickListener {
                closeOverlay()
                selectTab(t)
            }
            addView(c, lpm(8))
        }
    }
}

// ====================================================================== geçmiş / yer imleri

fun MainActivity.showEntries(bookmarks: Boolean) {
    val title = if (bookmarks) "Yer imleri" else "Geçmiş"
    showPage(title, "🗑", {
        AlertDialog.Builder(this)
            .setTitle("Tümü silinsin mi?")
            .setPositiveButton("Sil") { _, _ ->
                if (bookmarks) st.setStr("bookmarks", "[]") else st.clearHistory()
                showEntries(bookmarks)
            }
            .setNegativeButton("İptal", null)
            .show()
    }) {
        val search = EditText(this@showEntries)
        search.hint = "Ara"
        search.setHintTextColor(P.sub)
        search.setTextColor(P.text)
        search.setSingleLine()
        search.background = rounded(P.field, 20)
        search.setPadding(dp(16), dp(10), dp(16), dp(10))
        addView(search, lpm(8))

        val box = LinearLayout(this@showEntries)
        box.orientation = LinearLayout.VERTICAL
        addView(box, lpm(4))

        fun render(q: String) {
            box.removeAllViews()
            val ql = q.lowercase()
            val src = if (bookmarks) st.bookmarks() else st.history()
            val list = src.filter {
                ql.isEmpty() || it.title.lowercase().contains(ql) || it.url.lowercase().contains(ql)
            }.take(300)
            if (list.isEmpty()) {
                val e = tv("Burada henüz bir şey yok", 15f, P.sub)
                e.setPadding(0, dp(24), 0, 0)
                box.addView(e)
            }
            for (e in list) {
                val row = LinearLayout(this@showEntries)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(4), dp(8), dp(0), dp(8))
                val info = LinearLayout(this@showEntries)
                info.orientation = LinearLayout.VERTICAL
                val a = tv(e.title.ifBlank { e.url }, 15f, P.text, true)
                a.ellipsize1()
                val b = tv(e.url, 12f, P.sub)
                b.ellipsize1()
                info.addView(a)
                info.addView(b)
                row.addView(info, LinearLayout.LayoutParams(0, WC, 1f))
                row.addView(iconBtn("✕", 16f) {
                    if (bookmarks) st.removeBookmark(e.url) else st.removeHistory(e.url)
                    render(search.text.toString())
                })
                row.setOnClickListener {
                    closeOverlay()
                    openUrl(e.url, false)
                }
                row.setOnLongClickListener {
                    closeOverlay()
                    newTab(e.url, false)
                    true
                }
                box.addView(row)
            }
        }
        search.onText { render(it) }
        render("")
    }
}

fun MainActivity.showClearData() {
    val items = arrayOf("Geçmiş", "Çerezler ve site verileri", "Önbellek", "Yer imleri")
    val checked = booleanArrayOf(true, true, true, false)
    AlertDialog.Builder(this)
        .setTitle("Tarama verilerini sil")
        .setMultiChoiceItems(items, checked) { _, i, c -> checked[i] = c }
        .setPositiveButton("Sil") { _, _ ->
            if (checked[0]) st.clearHistory()
            if (checked[1]) {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            }
            if (checked[2]) cur?.web?.clearCache(true)
            if (checked[3]) st.setStr("bookmarks", "[]")
            toast("Silindi")
            val t = cur
            if (t != null && t.isStart) applyStart(t)
            refreshNav()
        }
        .setNegativeButton("İptal", null)
        .show()
}

// ====================================================================== ayarlar

private fun MainActivity.sectionTitle(s: String): TextView {
    val t = tv(s, 13f, P.accent, true)
    t.setPadding(0, dp(22), 0, dp(4))
    return t
}

private fun MainActivity.settingRow(title: String, value: String, onClick: () -> Unit): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.VERTICAL
    r.setPadding(dp(2), dp(12), dp(2), dp(12))
    r.addView(tv(title, 16f))
    if (value.isNotBlank()) {
        val v = tv(value, 13f, P.sub)
        v.ellipsize1()
        r.addView(v)
    }
    r.setOnClickListener { onClick() }
    return r
}

private fun MainActivity.switchRow(
    title: String,
    desc: String,
    key: String,
    def: Boolean,
    onChange: (Boolean) -> Unit = {}
): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.setPadding(dp(2), dp(10), dp(2), dp(10))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(tv(title, 16f))
    if (desc.isNotBlank()) col.addView(tv(desc, 12f, P.sub))
    r.addView(col, LinearLayout.LayoutParams(0, WC, 1f))
    val sw = SwitchCompat(this)
    sw.isChecked = st.bool(key, def)
    sw.setOnCheckedChangeListener { _, on ->
        st.setBool(key, on)
        onChange(on)
    }
    r.addView(sw)
    return r
}

fun MainActivity.showSettings() {
    val engines = listOf("google" to "Google", "duckduckgo" to "DuckDuckGo", "bing" to "Bing", "yandex" to "Yandex", "brave" to "Brave")
    val themes = listOf("system" to "Sistem varsayılanı", "dark" to "Siyah", "light" to "Beyaz")
    val zooms = listOf(80, 90, 100, 115, 130, 150)
    val prov = st.str("provider", "gemini")

    showPage("Ayarlar") {
        addView(sectionTitle("GENEL"))
        val curEngine = st.str("engine", "google")
        addView(settingRow("Arama motoru", engines.first { it.first == curEngine }.second) {
            choose("Arama motoru", engines.map { it.second }, engines.indexOfFirst { it.first == curEngine }) { i ->
                st.setStr("engine", engines[i].first)
                showSettings()
            }
        })
        val hp = st.str("homepage", "")
        addView(settingRow("Ana sayfa", if (hp.isBlank()) "Nova başlangıç sayfası" else hp) {
            inputDialog("Ana sayfa", hp, "boş = başlangıç sayfası") { v ->
                st.setStr("homepage", if (v.isBlank()) "" else resolve(v))
                showSettings()
            }
        })
        val curTheme = st.str("theme", "system")
        addView(settingRow("Tema", themes.first { it.first == curTheme }.second) {
            choose("Tema", themes.map { it.second }, themes.indexOfFirst { it.first == curTheme }) { i ->
                saveSession()
                st.setStr("theme", themes[i].first)
                AppCompatDelegate.setDefaultNightMode(
                    when (themes[i].first) {
                        "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                        "light" -> AppCompatDelegate.MODE_NIGHT_NO
                        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                    }
                )
                window.decorView.post {
                    if (!isFinishing && !isDestroyed) recreate()
                }
            }
        })
        addView(settingRow("Varsayılan tarayıcı yap", "Sistem ayarlarını açar") {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (e: Exception) {
                toast("Ayarlar açılamadı")
            }
        })

        addView(sectionTitle("GÖRÜNÜM"))
        val z = st.int("text_zoom", 100)
        addView(settingRow("Yazı boyutu", "$z%") {
            choose("Yazı boyutu", zooms.map { "$it%" }, zooms.indexOf(z)) { i ->
                st.setInt("text_zoom", zooms[i])
                applySettingsAll()
                showSettings()
            }
        })
        addView(switchRow("Masaüstü sitesini varsayılan yap", "Yeni sekmeler masaüstü sürümünde açılır", "desktop_default", false))
        addView(switchRow("Siteleri karart", "Koyu temada web sayfalarını karartır (Android 13+)", "web_dark", false) {
            applySettingsAll()
        })

        addView(sectionTitle("GİZLİLİK"))
        addView(switchRow("JavaScript", "Kapatırsan birçok site çalışmaz", "js", true) { applySettingsAll() })
        addView(settingRow("Tarama verilerini sil", "Geçmiş, çerezler, önbellek") { showClearData() })

        addView(sectionTitle("AI ASİSTAN"))
        addView(settingRow("Sağlayıcı", Ai.providerName(prov)) {
            choose("AI sağlayıcı", listOf("Gemini", "Groq"), if (prov == "groq") 1 else 0) { i ->
                st.setStr("provider", if (i == 1) "groq" else "gemini")
                showSettings()
            }
        })
        for (p in listOf("gemini", "groq")) {
            val name = Ai.providerName(p)
            val key = st.str("${p}_key", "")
            val model = st.str("${p}_model", Ai.DEFAULT_MODEL[p] ?: "")
            val hint = if (p == "gemini") "aistudio.google.com/apikey adresinden ücretsiz alabilirsin" else "console.groq.com/keys adresinden alabilirsin"
            addView(settingRow("$name API anahtarı", if (key.isBlank()) "Girilmedi · $hint" else "••••" + key.takeLast(4)) {
                inputDialog("$name API anahtarı", key, "API anahtarını yapıştır", true) { v ->
                    st.setStr("${p}_key", v)
                    showSettings()
                }
            })
            addView(settingRow("$name modeli", model + "  (dokun: listeden seç)") { pickModel(p) })
        }
        addView(switchRow("AI düğmesini göster", "Sağ altta sürüklenebilir ✨ düğmesi", "fab_show", true) { applySettingsAll() })
        addView(settingRow("AI düğmesi konumunu sıfırla", "Düğmeyi sürükleyerek de taşıyabilirsin") {
            st.setFloat("fab_fx", 1f)
            st.setFloat("fab_fy", 0.8f)
            positionFab()
            toast("Konum sıfırlandı")
        })

        addView(sectionTitle("HAKKINDA"))
        addView(settingRow("Nova Tarayıcı 1.0", "WebView tabanlı · Gemini & Groq destekli") {})
    }
}

fun MainActivity.pickModel(prov: String) {
    val key = st.str("${prov}_key", "")
    if (key.isBlank()) {
        toast("Önce API anahtarını gir")
        return
    }
    toast("Modeller getiriliyor…")
    Thread {
        val r = runCatching { Ai.listModels(prov, key) }
        runOnUiThread {
            r.onSuccess { list ->
                val cur = st.str("${prov}_model", Ai.DEFAULT_MODEL[prov] ?: "")
                AlertDialog.Builder(this)
                    .setTitle("${Ai.providerName(prov)} modeli")
                    .setSingleChoiceItems(list.toTypedArray(), list.indexOf(cur)) { dlg, which ->
                        st.setStr("${prov}_model", list[which])
                        dlg.dismiss()
                        showSettings()
                    }
                    .setNeutralButton("Elle gir") { _, _ -> inputModel(prov) }
                    .setNegativeButton("İptal", null)
                    .show()
            }
            r.onFailure {
                toast("Hata: " + (it.message ?: "bilinmiyor"))
                inputModel(prov)
            }
        }
    }.start()
}

fun MainActivity.inputModel(prov: String) {
    val cur = st.str("${prov}_model", Ai.DEFAULT_MODEL[prov] ?: "")
    inputDialog("Model adı", cur, "ör. " + (Ai.DEFAULT_MODEL[prov] ?: "")) { v ->
        if (v.isNotBlank()) st.setStr("${prov}_model", v)
        showSettings()
    }
}

// ====================================================================== başlangıç sayfası

fun MainActivity.buildStart(t: Tab) {
    startView.removeAllViews()
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.gravity = Gravity.CENTER_HORIZONTAL
    col.setPadding(dp(20), dp(36), dp(20), dp(100))

    fun center(s: String, size: Float, color: Int = P.text, bold: Boolean = false): TextView {
        val x = tv(s, size, color, bold)
        x.gravity = Gravity.CENTER
        return x
    }

    col.addView(center(if (t.incognito) "🕶" else "🌐", 54f))
    col.addView(center(if (t.incognito) "Gizli sekme" else "Nova", 30f, P.text, true))

    if (t.incognito) {
        val d = center(
            "Gizli sekmede gezdiklerin geçmişe kaydedilmez. Sekmeleri kapatınca bu sekmelerde bırakılan çerezler silinir.\n\n" +
                "Ziyaret ettiğin siteler, işverenin veya internet sağlayıcın tarafından yine de görülebilir.",
            14f, P.sub
        )
        d.setPadding(dp(8), dp(20), dp(8), 0)
        col.addView(d)
        startView.addView(col, ViewGroup.LayoutParams(MP, WC))
        return
    }

    val pill = center("🔍  Ara veya adres yaz", 15f, P.sub)
    pill.background = rounded(P.field, 28)
    pill.setPadding(dp(16), dp(14), dp(16), dp(14))
    pill.setOnClickListener { focusOmni() }
    col.addView(pill, lpm(22))

    val ai = center("✨  Nova AI'ye sor\n“Hepsiburada'yı aç” de, direkt açsın", 14f, P.text)
    ai.background = rounded(P.card, 16)
    ai.setPadding(dp(16), dp(12), dp(16), dp(12))
    ai.setOnClickListener { showAi() }
    col.addView(ai, lpm(12))

    val tiles = ArrayList<Pair<String, String>>()
    for (b in st.bookmarks().take(8)) tiles.add(Pair(b.title.ifBlank { b.url }, b.url))
    val defaults = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://www.youtube.com",
        "Hepsiburada" to "https://www.hepsiburada.com",
        "Trendyol" to "https://www.trendyol.com",
        "Vikipedi" to "https://tr.wikipedia.org",
        "GitHub" to "https://github.com",
        "X" to "https://x.com",
        "Instagram" to "https://www.instagram.com"
    )
    for (d in defaults) {
        val h = Uri.parse(d.second).host
        if (tiles.size < 8 && tiles.none { Uri.parse(it.second).host == h }) tiles.add(d)
    }

    val palette = intArrayOf(
        Color.parseColor("#3B82F6"), Color.parseColor("#E5484D"), Color.parseColor("#2EB67D"),
        Color.parseColor("#F5A524"), Color.parseColor("#8E4EC6"), Color.parseColor("#0EA5A5")
    )
    var i = 0
    while (i < tiles.size) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (j in 0 until 4) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(10), 0, dp(6))
            if (i + j < tiles.size) {
                val tile = tiles[i + j]
                val letter = tile.first.trim().take(1).uppercase().ifBlank { "?" }
                val av = tv(letter, 20f, Color.WHITE, true)
                av.gravity = Gravity.CENTER
                av.background = oval(palette[abs(tile.second.hashCode()) % palette.size])
                cell.addView(av, LinearLayout.LayoutParams(dp(52), dp(52)))
                val lb = tv(tile.first, 11f, P.sub)
                lb.gravity = Gravity.CENTER
                lb.ellipsize1()
                cell.addView(lb, LinearLayout.LayoutParams(MP, WC))
                cell.setOnClickListener { load(t, tile.second) }
            }
            row.addView(cell, LinearLayout.LayoutParams(0, WC, 1f))
        }
        col.addView(row, lpm(4))
        i += 4
    }
    startView.addView(col, ViewGroup.LayoutParams(MP, WC))
}

// ====================================================================== öneriler

fun MainActivity.updateSuggest(q: String) {
    if (settingOmni || !omni.hasFocus() || q.isBlank()) {
        hideSuggest()
        return
    }
    suggestBox.removeAllViews()

    fun addRow(icon: String, title: String, sub: String, url: String) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(10), dp(12), dp(10))
        val ic = tv(icon, 16f)
        ic.gravity = Gravity.CENTER
        r.addView(ic, LinearLayout.LayoutParams(dp(32), WC))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val a = tv(title, 15f)
        a.ellipsize1()
        col.addView(a)
        if (sub.isNotBlank()) {
            val b = tv(sub, 12f, P.sub)
            b.ellipsize1()
            col.addView(b)
        }
        r.addView(col, LinearLayout.LayoutParams(0, WC, 1f))
        r.setOnClickListener {
            hideKeyboard()
            hideSuggest()
            webContainer.requestFocus()
            load(tab(), url)
        }
        suggestBox.addView(r)
    }

    addRow("🔍", q, "Ara veya git", q)
    val ql = q.lowercase()
    val seen = HashSet<String>()
    val pool = st.bookmarks().map { Pair("⭐", it) } + st.history().map { Pair("🕘", it) }
    var n = 0
    for (p in pool) {
        if (n >= 5) break
        val e = p.second
        if (!seen.add(e.url)) continue
        if (e.title.lowercase().contains(ql) || e.url.lowercase().contains(ql)) {
            addRow(p.first, e.title.ifBlank { e.url }, e.url, e.url)
            n++
        }
    }
    suggestBox.visibility = View.VISIBLE
}

fun MainActivity.hideSuggest() {
    suggestBox.visibility = View.GONE
}

// ====================================================================== AI asistan

fun MainActivity.showAi() {
    if (aiDialog?.isShowing == true) return
    val d = BottomSheetDialog(this)
    aiDialog = d
    val h = (resources.displayMetrics.heightPixels * 0.78f).toInt()

    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setBackgroundColor(P.bar)

    val prov = st.str("provider", "gemini")
    val model = st.str("${prov}_model", Ai.DEFAULT_MODEL[prov] ?: "")

    val head = LinearLayout(this)
    head.orientation = LinearLayout.HORIZONTAL
    head.gravity = Gravity.CENTER_VERTICAL
    head.setPadding(dp(16), dp(8), dp(4), dp(4))
    val titles = LinearLayout(this)
    titles.orientation = LinearLayout.VERTICAL
    titles.addView(tv("✨ Nova AI", 18f, P.text, true))
    val sub = tv("${Ai.providerName(prov)} · $model", 12f, P.sub)
    sub.ellipsize1()
    titles.addView(sub)
    head.addView(titles, LinearLayout.LayoutParams(0, WC, 1f))
    head.addView(iconBtn("🗑", 18f) {
        aiMsgs.clear()
        renderAi()
    })
    head.addView(iconBtn("⚙️", 18f) {
        d.dismiss()
        showSettings()
    })
    head.addView(iconBtn("✕", 18f) { d.dismiss() })
    box.addView(head)
    box.addView(divider())

    val sv = ScrollView(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(12), dp(6), dp(12), dp(6))
    sv.addView(col, ViewGroup.LayoutParams(MP, WC))
    aiCol = col
    aiScroll = sv
    box.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))

    val chipsScroll = HorizontalScrollView(this)
    chipsScroll.isHorizontalScrollBarEnabled = false
    val chips = LinearLayout(this)
    chips.orientation = LinearLayout.HORIZONTAL
    chips.setPadding(dp(10), dp(4), dp(10), dp(4))
    fun chip(label: String, text: String) {
        val c = pill(label) { aiSend(text) }
        val lp = LinearLayout.LayoutParams(WC, WC)
        lp.rightMargin = dp(6)
        chips.addView(c, lp)
    }
    chip("📄 Sayfayı özetle", "Bu sayfayı özetle")
    chip("🛒 Hepsiburada'yı aç", "Hepsiburada'yı aç")
    chip("🕶 Gizli sekme", "Gizli sekme aç")
    chip("🖥 Masaüstü modu", "Masaüstü sitesini aç")
    chipsScroll.addView(chips)
    box.addView(chipsScroll)

    val inRow = LinearLayout(this)
    inRow.orientation = LinearLayout.HORIZONTAL
    inRow.gravity = Gravity.CENTER_VERTICAL
    inRow.setPadding(dp(10), dp(4), dp(6), dp(10))
    val input = EditText(this)
    input.hint = "Sor veya komut ver…"
    input.setHintTextColor(P.sub)
    input.setTextColor(P.text)
    input.setSingleLine()
    input.imeOptions = EditorInfo.IME_ACTION_SEND
    input.background = rounded(P.field, 24)
    input.setPadding(dp(16), dp(10), dp(16), dp(10))
    fun send() {
        val s = input.text.toString().trim()
        if (s.isNotEmpty()) {
            input.setText("")
            aiSend(s)
        }
    }
    input.setOnEditorActionListener { _, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_SEND) {
            send()
            true
        } else {
            false
        }
    }
    inRow.addView(input, LinearLayout.LayoutParams(0, WC, 1f))
    inRow.addView(iconBtn("🎤", 20f) { startVoice("ai") })
    inRow.addView(iconBtn("➤", 20f) { send() })
    box.addView(inRow)

    d.setOnDismissListener {
        aiCol = null
        aiScroll = null
        aiDialog = null
    }
    d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    d.setContentView(box, ViewGroup.LayoutParams(MP, h))
    d.expand()
    d.show()

    if (aiMsgs.isEmpty()) {
        aiMsgs.add(
            AiMsg(
                "ai",
                "Merhaba! Şunları yapabilirim:\n• “Trendyol'u aç” → siteyi direkt açarım (arama yapmam)\n" +
                    "• “Bu sayfayı özetle”\n• Her türlü soru ve sohbet\n• “Yeni gizli sekme aç”, “masaüstü sitesi”…",
                false
            )
        )
    }
    renderAi()
}

private fun cleanMd(s: String): String {
    return s.replace("**", "")
        .replace(Regex("(?m)^\\s*[*-] "), "• ")
        .replace(Regex("(?m)^#+\\s*"), "")
        .trim()
}

fun MainActivity.renderAi() {
    val col = aiCol ?: return
    col.removeAllViews()
    val maxW = (resources.displayMetrics.widthPixels * 0.85f).toInt()
    for (m in aiMsgs) {
        val user = m.role == "user"
        val t = TextView(this)
        t.text = if (user) m.text else cleanMd(m.text)
        t.textSize = 15f
        t.setTextColor(if (user) Color.WHITE else P.text)
        t.setTextIsSelectable(true)
        t.background = rounded(if (user) P.accent else P.card, 16)
        t.setPadding(dp(12), dp(9), dp(12), dp(9))
        t.maxWidth = maxW
        val lp = LinearLayout.LayoutParams(WC, WC)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.topMargin = dp(6)
        col.addView(t, lp)
    }
    val s = aiScroll
    s?.post { s.fullScroll(View.FOCUS_DOWN) }
}

fun MainActivity.aiAdd(role: String, text: String, api: Boolean = true) {
    aiMsgs.add(AiMsg(role, text, api))
    while (aiMsgs.size > 60) aiMsgs.removeAt(0)
    renderAi()
}

private fun MainActivity.apiHistory(): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    for (m in aiMsgs.filter { it.api }.takeLast(14)) {
        if (out.isNotEmpty() && out[out.size - 1].first == m.role) {
            val l = out.removeAt(out.size - 1)
            out.add(Pair(l.first, l.second + "\n" + m.text))
        } else {
            out.add(Pair(m.role, m.text))
        }
    }
    while (out.isNotEmpty() && out[0].first != "user") out.removeAt(0)
    return out
}

fun MainActivity.aiSend(text: String) {
    if (text.isBlank()) return
    aiAdd("user", text)

    val local = Ai.local(text)
    if (local != null) {
        aiExecute(local)
        return
    }

    val prov = st.str("provider", "gemini")
    val key = st.str("${prov}_key", "")
    if (key.isBlank()) {
        aiAdd(
            "ai",
            "⚠️ ${Ai.providerName(prov)} API anahtarı girilmemiş. ⚙️ Ayarlar > AI Asistan bölümünden ekleyebilirsin.\n" +
                "(Bilinen siteleri “Trendyol'u aç” gibi komutlarla anahtar olmadan da açabilirim.)",
            false
        )
        return
    }
    val model = st.str("${prov}_model", Ai.DEFAULT_MODEL[prov] ?: "")
    val c = cur
    val pageUrl = if (c == null || c.isStart) "" else c.url
    val system = Ai.systemPrompt(c?.title ?: "", pageUrl)
    val hist = apiHistory()

    val thinking = AiMsg("ai", "…", false)
    aiMsgs.add(thinking)
    renderAi()

    Thread {
        val r = runCatching { Ai.ask(prov, key, model, system, hist, true) }
        runOnUiThread {
            aiMsgs.remove(thinking)
            r.onSuccess { raw -> aiExecute(Ai.parseCmd(raw)) }
            r.onFailure { aiAdd("ai", "❌ " + (it.message ?: "Bilinmeyen hata"), false) }
        }
    }.start()
}

private fun fixUrl(u: String): String? {
    var s = u.trim()
    if (s.isEmpty()) return null
    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
    val host = Uri.parse(s).host ?: return null
    return if (host.contains('.')) s else null
}

fun MainActivity.aiExecute(c: Ai.Cmd) {
    val say = c.say
    when (c.action) {
        "open" -> {
            val url = fixUrl(c.url)
            if (url == null) {
                aiAdd("ai", "Geçerli bir adres bulamadım. Tam adresi yazar mısın?", false)
                return
            }
            aiAdd("ai", if (say.isNotBlank()) say else "Açılıyor: $url")
            aiDialog?.dismiss()
            closeOverlay()
            openUrl(url, c.newtab)
        }
        "search" -> {
            val q = c.query.ifBlank { say }
            aiAdd("ai", if (say.isNotBlank()) say else "Aranıyor: $q")
            aiDialog?.dismiss()
            closeOverlay()
            load(tab(), q)
        }
        "page" -> aiPage(c.question, say)
        "newtab" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Yeni sekme açıldı.")
            aiDialog?.dismiss()
            closeOverlay()
            newTab(null, false)
            focusOmni()
        }
        "incognito" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Gizli sekme açıldı.")
            aiDialog?.dismiss()
            closeOverlay()
            newTab(null, true)
        }
        "back" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Geri gidiliyor.")
            aiDialog?.dismiss()
            val w = tab().web
            if (w.canGoBack()) w.goBack()
        }
        "forward" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "İleri gidiliyor.")
            aiDialog?.dismiss()
            val w = tab().web
            if (w.canGoForward()) w.goForward()
        }
        "reload" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Sayfa yenileniyor.")
            aiDialog?.dismiss()
            if (!tab().isStart) tab().web.reload()
        }
        "bookmark" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Yer imi güncellendi.")
            toggleBookmark()
        }
        "closetab" -> {
            aiAdd("ai", if (say.isNotBlank()) say else "Sekme kapatıldı.")
            aiDialog?.dismiss()
            closeTab(tab())
        }
        "desktop" -> {
            aiAdd("ai", if (say.isNotBlank()) say else if (c.value) "Masaüstü sitesi açıldı." else "Mobil siteye dönüldü.")
            setDesktop(tab(), c.value)
        }
        else -> aiAdd("ai", if (say.isNotBlank()) say else "…")
    }
}

private fun decodeJs(raw: String?): String {
    if (raw == null || raw == "null") return ""
    return try {
        val v = org.json.JSONTokener(raw).nextValue()
        if (v is String) v else ""
    } catch (e: Exception) {
        ""
    }
}

fun MainActivity.aiPage(question: String, say: String) {
    val t = tab()
    if (t.isStart) {
        aiAdd("ai", "Açık bir sayfa yok. Önce bir site aç.", false)
        return
    }
    val prov = st.str("provider", "gemini")
    val key = st.str("${prov}_key", "")
    if (key.isBlank()) {
        aiAdd("ai", "⚠️ Sayfayı özetlemek için API anahtarı gerekli (⚙️ Ayarlar > AI Asistan).", false)
        return
    }
    val model = st.str("${prov}_model", Ai.DEFAULT_MODEL[prov] ?: "")
    if (say.isNotBlank()) aiAdd("ai", say, false)
    val thinking = AiMsg("ai", "…", false)
    aiMsgs.add(thinking)
    renderAi()

    val js = "(function(){return document.body?document.body.innerText:''})()"
    t.web.evaluateJavascript(js) { raw ->
        val text = decodeJs(raw).take(14000)
        val ask = if (question.isBlank()) "Bu sayfayı kısaca özetle." else question
        val msg = "Sayfa: ${t.title} (${t.url})\n\nİçerik:\n$text\n\nİstek: $ask"
        Thread {
            val r = runCatching { Ai.ask(prov, key, model, Ai.PAGE_PROMPT, listOf(Pair("user", msg)), false) }
            runOnUiThread {
                aiMsgs.remove(thinking)
                r.onSuccess { aiAdd("ai", it) }
                r.onFailure { aiAdd("ai", "❌ " + (it.message ?: "Bilinmeyen hata"), false) }
            }
        }.start()
    }
}
