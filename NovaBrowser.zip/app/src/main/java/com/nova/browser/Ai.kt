package com.nova.browser

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {

    class Cmd(
        val action: String,
        val url: String = "",
        val query: String = "",
        val say: String = "",
        val newtab: Boolean = false,
        val value: Boolean = true,
        val question: String = ""
    )

    val DEFAULT_MODEL = mapOf(
        "gemini" to "gemini-2.5-flash",
        "groq" to "llama-3.3-70b-versatile"
    )

    fun providerName(p: String): String = if (p == "groq") "Groq" else "Gemini"

    // ---------------------------------------------------------------- Yerel site eşlemesi
    // Anahtarlar sadeleştirilmiş (ascii, küçük harf) yazılır.
    private val SITES: List<Pair<String, String>> = listOf(
        "hepsiburada" to "https://www.hepsiburada.com",
        "hepsiemlak" to "https://www.hepsiemlak.com",
        "trendyol" to "https://www.trendyol.com",
        "n11" to "https://www.n11.com",
        "amazon" to "https://www.amazon.com.tr",
        "sahibinden" to "https://www.sahibinden.com",
        "ciceksepeti" to "https://www.ciceksepeti.com",
        "teknosa" to "https://www.teknosa.com",
        "mediamarkt" to "https://www.mediamarkt.com.tr",
        "vatan" to "https://www.vatanbilgisayar.com",
        "itopya" to "https://www.itopya.com",
        "incehesap" to "https://www.incehesap.com",
        "getir" to "https://getir.com",
        "yemeksepeti" to "https://www.yemeksepeti.com",
        "migros" to "https://www.migros.com.tr",
        "a101" to "https://www.a101.com.tr",
        "bim" to "https://www.bim.com.tr",
        "boyner" to "https://www.boyner.com.tr",
        "lc waikiki" to "https://www.lcw.com",
        "lcw" to "https://www.lcw.com",
        "defacto" to "https://www.defacto.com.tr",
        "koton" to "https://www.koton.com",
        "flo" to "https://www.flo.com.tr",
        "decathlon" to "https://www.decathlon.com.tr",
        "youtube" to "https://www.youtube.com",
        "google" to "https://www.google.com",
        "gmail" to "https://mail.google.com",
        "google harita" to "https://maps.google.com",
        "harita" to "https://maps.google.com",
        "google drive" to "https://drive.google.com",
        "drive" to "https://drive.google.com",
        "twitter" to "https://x.com",
        "instagram" to "https://www.instagram.com",
        "facebook" to "https://www.facebook.com",
        "tiktok" to "https://www.tiktok.com",
        "whatsapp" to "https://web.whatsapp.com",
        "telegram" to "https://web.telegram.org",
        "linkedin" to "https://www.linkedin.com",
        "reddit" to "https://www.reddit.com",
        "pinterest" to "https://www.pinterest.com",
        "github" to "https://github.com",
        "wikipedia" to "https://tr.wikipedia.org",
        "vikipedi" to "https://tr.wikipedia.org",
        "eksi sozluk" to "https://eksisozluk.com",
        "netflix" to "https://www.netflix.com",
        "spotify" to "https://open.spotify.com",
        "twitch" to "https://www.twitch.tv",
        "disney" to "https://www.disneyplus.com",
        "exxen" to "https://www.exxen.com",
        "blutv" to "https://www.blutv.com",
        "e devlet" to "https://www.turkiye.gov.tr",
        "edevlet" to "https://www.turkiye.gov.tr",
        "ptt" to "https://www.ptt.gov.tr",
        "thy" to "https://www.turkishairlines.com",
        "turk hava yollari" to "https://www.turkishairlines.com",
        "pegasus" to "https://www.flypgs.com",
        "obilet" to "https://www.obilet.com",
        "enuygun" to "https://www.enuygun.com",
        "booking" to "https://www.booking.com",
        "airbnb" to "https://www.airbnb.com.tr",
        "hurriyet" to "https://www.hurriyet.com.tr",
        "milliyet" to "https://www.milliyet.com.tr",
        "sabah" to "https://www.sabah.com.tr",
        "sozcu" to "https://www.sozcu.com.tr",
        "ntv" to "https://www.ntv.com.tr",
        "cnn turk" to "https://www.cnnturk.com",
        "haberturk" to "https://www.haberturk.com",
        "mackolik" to "https://www.mackolik.com",
        "chatgpt" to "https://chatgpt.com",
        "claude" to "https://claude.ai",
        "gemini" to "https://gemini.google.com",
        "bing" to "https://www.bing.com",
        "duckduckgo" to "https://duckduckgo.com",
        "yandex" to "https://yandex.com.tr",
        "steam" to "https://store.steampowered.com",
        "epic games" to "https://store.epicgames.com",
        "udemy" to "https://www.udemy.com",
        "stackoverflow" to "https://stackoverflow.com"
    )

    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase(java.util.Locale("tr", "TR"))) {
            val c = when (ch) {
                'ı', 'İ' -> 'i'
                'ö' -> 'o'
                'ü' -> 'u'
                'ş' -> 's'
                'ç' -> 'c'
                'ğ' -> 'g'
                else -> ch
            }
            sb.append(if (c.isLetterOrDigit()) c else ' ')
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private val OPEN_WORDS = Regex("(^| )(ac|acar misin|git|gir|gidelim|ziyaret et|goster|open)( |$)")
    private val DOMAIN = Regex("([a-z0-9-]+\\.)+[a-z]{2,}(/[^\\s]*)?")

    /** Ağ gerektirmeyen hızlı komutlar. Eşleşme yoksa null döner. */
    fun local(text: String): Cmd? {
        val t = norm(text)
        val words = if (t.isEmpty()) 0 else t.split(" ").size
        val wantsOpen = OPEN_WORDS.containsMatchIn(t)
        val newTab = t.contains("yeni sekme") || t.contains("yeni sekmede")

        if (wantsOpen) {
            // Önce açık alan adı: "example.com aç"
            val dm = DOMAIN.find(text.lowercase())
            if (dm != null) {
                return Cmd("open", url = "https://" + dm.value, newtab = newTab, say = dm.value + " açılıyor…")
            }
            // Bilinen siteler (uzun anahtarlar önce)
            for (p in SITES.sortedByDescending { it.first.length }) {
                if (Regex("(^| )" + Regex.escape(p.first)).containsMatchIn(t)) {
                    return Cmd("open", url = p.second, newtab = newTab, say = p.second.removePrefix("https://") + " açılıyor…")
                }
            }
        }
        if (words <= 4) {
            if (t.contains("gizli sekme")) return Cmd("incognito", say = "Gizli sekme açıldı.")
            if (t.contains("yeni sekme")) return Cmd("newtab", say = "Yeni sekme açıldı.")
            if (t == "geri" || t == "geri git" || t == "geriye git") return Cmd("back", say = "Geri gidiliyor.")
            if (t == "ileri" || t == "ileri git") return Cmd("forward", say = "İleri gidiliyor.")
            if (t == "yenile" || t == "sayfayi yenile") return Cmd("reload", say = "Sayfa yenileniyor.")
            if (t.contains("masaustu") && (t.contains("ac") || t.contains("mod") || t.contains("site"))) {
                return Cmd("desktop", value = true, say = "Masaüstü sitesi açıldı.")
            }
            if (t.contains("mobil") && (t.contains("mod") || t.contains("site"))) {
                return Cmd("desktop", value = false, say = "Mobil siteye dönüldü.")
            }
            if (t.contains("yer imi") && (t.contains("ekle") || t.contains("kaydet"))) {
                return Cmd("bookmark", say = "Yer imi güncellendi.")
            }
            if (t.contains("sekmeyi kapat")) return Cmd("closetab", say = "Sekme kapatıldı.")
        }
        return null
    }

    // ---------------------------------------------------------------- Sistem istemi
    fun systemPrompt(pageTitle: String, pageUrl: String): String {
        return "Sen Nova tarayıcısının yerleşik asistanısın. Kullanıcıyla kullanıcının dilinde (varsayılan Türkçe) kısa ve net konuş.\n" +
            "Her yanıtı YALNIZCA tek bir JSON nesnesi olarak ver. Kod bloğu, açıklama veya ek metin yazma.\n" +
            "Şemalar:\n" +
            "{\"action\":\"open\",\"url\":\"https://...\",\"newtab\":false,\"say\":\"kısa mesaj\"} -> kullanıcı bir siteyi açmak veya oraya gitmek istiyorsa. " +
            "ARAMA YAPMA. Sitenin RESMİ ana sayfa adresini ver (Türkiye için varsa .com.tr gibi yerel alan adı). Emin değilsen en olası resmi adresi ver.\n" +
            "{\"action\":\"search\",\"query\":\"...\",\"say\":\"...\"} -> yalnızca kullanıcı açıkça bir şey aratmak istiyorsa.\n" +
            "{\"action\":\"page\",\"question\":\"...\",\"say\":\"...\"} -> kullanıcı açık sayfayı özetletmek veya o sayfa hakkında soru sormak istiyorsa.\n" +
            "{\"action\":\"newtab\"|\"incognito\"|\"back\"|\"forward\"|\"reload\"|\"bookmark\"|\"closetab\",\"say\":\"...\"} -> tarayıcı komutları.\n" +
            "{\"action\":\"desktop\",\"value\":true,\"say\":\"...\"} -> masaüstü sitesini aç (true) veya kapat (false).\n" +
            "{\"action\":\"chat\",\"say\":\"cevap\"} -> diğer her şey (sohbet, bilgi soruları, öneriler).\n" +
            "Şu an açık sayfa: " + (if (pageUrl.isBlank()) "yok" else "$pageTitle - $pageUrl")
    }

    const val PAGE_PROMPT =
        "Sen Nova tarayıcısının asistanısın. Verilen web sayfası içeriğine dayanarak kullanıcının isteğine kullanıcının dilinde " +
            "(varsayılan Türkçe) açık ve kısa yanıt ver. JSON değil, düz metin yaz."

    fun parseCmd(raw: String): Cmd {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return Cmd("chat", say = raw.trim())
        return try {
            val o = JSONObject(raw.substring(s, e + 1))
            Cmd(
                action = o.optString("action", "chat"),
                url = o.optString("url", ""),
                query = o.optString("query", ""),
                say = o.optString("say", ""),
                newtab = o.optBoolean("newtab", false),
                value = o.optBoolean("value", true),
                question = o.optString("question", "")
            )
        } catch (ex: Exception) {
            Cmd("chat", say = raw.trim())
        }
    }

    // ---------------------------------------------------------------- HTTP
    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 60000
        for ((k, v) in headers) c.setRequestProperty(k, v)
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: " + errMsg(text))
        return text
    }

    private fun errMsg(text: String): String {
        return try {
            val o = JSONObject(text)
            val er = o.optJSONObject("error")
            er?.optString("message") ?: text.take(200)
        } catch (e: Exception) {
            text.take(200)
        }
    }

    /** msgs: (rol "user"/"ai", metin) çiftleri. */
    fun ask(
        provider: String,
        key: String,
        model: String,
        system: String,
        msgs: List<Pair<String, String>>,
        json: Boolean
    ): String {
        return if (provider == "groq") askGroq(key, model, system, msgs) else askGemini(key, model, system, msgs, json)
    }

    private fun askGemini(
        key: String,
        model: String,
        system: String,
        msgs: List<Pair<String, String>>,
        json: Boolean
    ): String {
        val m = model.removePrefix("models/")
        val contents = JSONArray()
        for ((r, t) in msgs) {
            contents.put(
                JSONObject()
                    .put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val res = http(
            "POST",
            "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
            mapOf("Content-Type" to "application/json", "x-goog-api-key" to key),
            body.toString()
        )
        val o = JSONObject(res)
        val cands = o.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw Exception("Yanıt alınamadı (içerik engellenmiş olabilir).")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Boş yanıt.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun askGroq(
        key: String,
        model: String,
        system: String,
        msgs: List<Pair<String, String>>
    ): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        for ((r, t) in msgs) {
            arr.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t))
        }
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.4)
        val res = http(
            "POST",
            "https://api.groq.com/openai/v1/chat/completions",
            mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"),
            body.toString()
        )
        val o = JSONObject(res)
        val choices = o.optJSONArray("choices")
        if (choices == null || choices.length() == 0) throw Exception("Boş yanıt.")
        return choices.getJSONObject(0).getJSONObject("message").optString("content", "")
    }

    fun listModels(provider: String, key: String): List<String> {
        val out = mutableListOf<String>()
        if (provider == "groq") {
            val res = http(
                "GET", "https://api.groq.com/openai/v1/models",
                mapOf("Authorization" to "Bearer $key"), null
            )
            val arr = JSONObject(res).optJSONArray("data") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val id = arr.getJSONObject(i).optString("id")
                if (id.isNotBlank() && !id.contains("whisper") && !id.contains("tts") && !id.contains("guard")) out.add(id)
            }
        } else {
            val res = http(
                "GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                mapOf("x-goog-api-key" to key), null
            )
            val arr = JSONObject(res).optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val methods = o.optJSONArray("supportedGenerationMethods")
                var ok = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") ok = true
                    }
                }
                if (ok) out.add(o.optString("name").removePrefix("models/"))
            }
        }
        out.sort()
        if (out.isEmpty()) throw Exception("Model listesi boş geldi.")
        return out
    }
}
