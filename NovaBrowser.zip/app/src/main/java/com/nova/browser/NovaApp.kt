package com.nova.browser

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class NovaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val theme = getSharedPreferences("nova", Context.MODE_PRIVATE).getString("theme", "system")
        AppCompatDelegate.setDefaultNightMode(
            when (theme) {
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
