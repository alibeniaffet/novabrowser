package com.nova.browser

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

private fun cmdIntent(ctx: Context, cmd: String): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java)
    i.action = "com.nova.browser.CMD." + cmd
    i.putExtra("cmd", cmd)
    i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
    return PendingIntent.getActivity(
        ctx,
        cmd.hashCode(),
        i,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

/** Arama çubuğu: yaz, sesle ara, AI aç. */
class SearchWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val rv = RemoteViews(context.packageName, R.layout.widget_search)
        rv.setOnClickPendingIntent(R.id.w_pill, cmdIntent(context, "search"))
        rv.setOnClickPendingIntent(R.id.w_hint, cmdIntent(context, "search"))
        rv.setOnClickPendingIntent(R.id.w_mic, cmdIntent(context, "voice"))
        rv.setOnClickPendingIntent(R.id.w_ai, cmdIntent(context, "ai"))
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, rv)
    }
}

/** Doğrudan AI asistanını açan widget. */
class AiWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val rv = RemoteViews(context.packageName, R.layout.widget_ai)
        rv.setOnClickPendingIntent(R.id.w_ai_root, cmdIntent(context, "ai"))
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, rv)
    }
}

/** Kısayollar: yeni sekme, gizli sekme, yer imleri, sesli arama. */
class ShortcutsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val rv = RemoteViews(context.packageName, R.layout.widget_shortcuts)
        rv.setOnClickPendingIntent(R.id.w_s1, cmdIntent(context, "newtab"))
        rv.setOnClickPendingIntent(R.id.w_s2, cmdIntent(context, "incognito"))
        rv.setOnClickPendingIntent(R.id.w_s3, cmdIntent(context, "bookmarks"))
        rv.setOnClickPendingIntent(R.id.w_s4, cmdIntent(context, "voice"))
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, rv)
    }
}
