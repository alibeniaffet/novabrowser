package com.nova.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Entry(val title: String, val url: String, val ts: Long)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun setStr(k: String, v: String) {
        sp.edit().putString(k, v).apply()
    }

    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun setBool(k: String, v: Boolean) {
        sp.edit().putBoolean(k, v).apply()
    }

    fun int(k: String, d: Int): Int = sp.getInt(k, d)
    fun setInt(k: String, v: Int) {
        sp.edit().putInt(k, v).apply()
    }

    fun float(k: String, d: Float): Float = sp.getFloat(k, d)
    fun setFloat(k: String, v: Float) {
        sp.edit().putFloat(k, v).apply()
    }

    fun remove(k: String) {
        sp.edit().remove(k).apply()
    }

    // ---------- Liste (yer imleri / geçmiş) ----------
    private fun readList(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(str(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u"), o.optLong("ts")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun writeList(key: String, list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().put("t", e.title).put("u", e.url).put("ts", e.ts))
        }
        setStr(key, arr.toString())
    }

    fun bookmarks(): MutableList<Entry> = readList("bookmarks")

    fun isBookmarked(url: String): Boolean = bookmarks().any { it.url == url }

    fun toggleBookmark(title: String, url: String): Boolean {
        val list = bookmarks()
        val existing = list.firstOrNull { it.url == url }
        return if (existing != null) {
            list.remove(existing)
            writeList("bookmarks", list)
            false
        } else {
            list.add(0, Entry(title, url, System.currentTimeMillis()))
            writeList("bookmarks", list)
            true
        }
    }

    fun removeBookmark(url: String) {
        val list = bookmarks()
        list.removeAll { it.url == url }
        writeList("bookmarks", list)
    }

    fun history(): MutableList<Entry> = readList("history")

    fun addHistory(title: String, url: String) {
        if (url.startsWith("data:") || url.startsWith("about:") || url.isBlank()) return
        val list = history()
        if (list.isNotEmpty() && list[0].url == url) {
            list[0] = Entry(title.ifBlank { url }, url, System.currentTimeMillis())
        } else {
            list.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
        }
        while (list.size > 600) list.removeAt(list.size - 1)
        writeList("history", list)
    }

    fun removeHistory(url: String) {
        val list = history()
        list.removeAll { it.url == url }
        writeList("history", list)
    }

    fun clearHistory() {
        setStr("history", "[]")
    }

    // ---------- Oturum ----------
    fun saveSession(items: List<Pair<String, String>>, cur: Int) {
        val arr = JSONArray()
        for (p in items) arr.put(JSONObject().put("u", p.first).put("t", p.second))
        setStr("session", JSONObject().put("tabs", arr).put("cur", cur).toString())
    }

    fun loadSession(): Pair<List<Pair<String, String>>, Int> {
        val out = mutableListOf<Pair<String, String>>()
        var cur = 0
        try {
            val o = JSONObject(str("session", "{}"))
            val arr = o.optJSONArray("tabs")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val t = arr.getJSONObject(i)
                    out.add(Pair(t.optString("u"), t.optString("t")))
                }
            }
            cur = o.optInt("cur", 0)
        } catch (e: Exception) {
        }
        return Pair(out, cur)
    }
}
