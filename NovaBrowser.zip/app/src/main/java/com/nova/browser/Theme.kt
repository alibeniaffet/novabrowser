package com.nova.browser

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object P {
    var dark = false
    var bg = 0
    var bar = 0
    var field = 0
    var text = 0
    var sub = 0
    var card = 0
    var line = 0
    val accent: Int = Color.parseColor("#3B82F6")
    val danger: Int = Color.parseColor("#E5484D")

    fun init(night: Boolean, black: Boolean) {
        dark = night
        if (!night) {
            bg = Color.parseColor("#FFFFFF")
            bar = Color.parseColor("#FFFFFF")
            field = Color.parseColor("#F1F3F4")
            text = Color.parseColor("#202124")
            sub = Color.parseColor("#5F6368")
            card = Color.parseColor("#F1F3F4")
            line = Color.parseColor("#DADCE0")
        } else if (black) {
            bg = Color.parseColor("#000000")
            bar = Color.parseColor("#0A0A0A")
            field = Color.parseColor("#1C1C1E")
            text = Color.parseColor("#FFFFFF")
            sub = Color.parseColor("#9AA0A6")
            card = Color.parseColor("#151517")
            line = Color.parseColor("#2A2A2D")
        } else {
            bg = Color.parseColor("#1B1B1F")
            bar = Color.parseColor("#202124")
            field = Color.parseColor("#303134")
            text = Color.parseColor("#E8EAED")
            sub = Color.parseColor("#9AA0A6")
            card = Color.parseColor("#292A2D")
            line = Color.parseColor("#3C4043")
        }
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, radius: Int = 12): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = dp(radius).toFloat()
    return d
}

fun Context.oval(color: Int): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.OVAL
    d.setColor(color)
    return d
}

fun Context.tv(
    s: String,
    size: Float = 15f,
    color: Int = P.text,
    bold: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.iconBtn(label: String, size: Float = 20f, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = label
    t.textSize = size
    t.setTextColor(P.text)
    t.gravity = Gravity.CENTER
    val out = TypedValue()
    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, out, true)
    t.setBackgroundResource(out.resourceId)
    t.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
    t.setOnClickListener { onClick() }
    return t
}

fun Context.pill(label: String, color: Int = P.field, textColor: Int = P.text, onClick: () -> Unit): TextView {
    val t = tv(label, 14f, textColor)
    t.background = rounded(color, 20)
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.setOnClickListener { onClick() }
    return t
}

fun Context.divider(): android.view.View {
    val v = android.view.View(this)
    v.setBackgroundColor(P.line)
    v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    return v
}

fun TextView.ellipsize1() {
    maxLines = 1
    ellipsize = TextUtils.TruncateAt.END
}

fun EditText.onText(cb: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            cb(s?.toString() ?: "")
        }
    })
}
