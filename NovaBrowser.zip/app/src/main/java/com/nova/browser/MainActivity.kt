package com.nova.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.speech.RecognizerIntent
import android.util.Patterns
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs

const val MP = ViewGroup.LayoutParams.MATCH_PARENT
const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
const val FAB_SIZE = 54

class Tab(val id: Int, val incognito: Boolean, val web: WebView) {
    var title = "Yeni sekme"
    var url = ""
    var isStart = true
    var desktop = false
    var progress = 0
    var parent: Tab? = null
    var pending: String? = null
}

class AiMsg(val role: String, var text: String, val api: Boolean = true)

fun BottomSheetDialog.expand() {
    behavior.state = BottomSheetBehavior.STATE_EXPANDED
    behavior.skipCollapsed = true
}

class MainActivity : AppCompatActivity() {

    lateinit var st: Store
    lateinit var root: FrameLayout
    lateinit var main: LinearLayout
    lateinit var topBar: LinearLayout
    lateinit var overlay: FrameLayout
    lateinit var fullscreen: FrameLayout
    lateinit var omni: EditText
    lateinit var lockIcon: TextView
    lateinit var tabCountTv: TextView
    lateinit var progressBar: ProgressBar
    lateinit var webContainer: FrameLayout
    lateinit var startView: ScrollView
    lateinit var suggestBox: LinearLayout
    lateinit var findBar: LinearLayout
    lateinit var findInput: EditText
    lateinit var findCount: TextView
    lateinit var btnBack: TextView
    lateinit var btnFwd: TextView
    lateinit var btnReload: TextView
    lateinit var btnStar: TextView
    lateinit var fab: TextView

    val tabs = ArrayList<Tab>()
    var cur: Tab? = null
    var nextId = 1
    var mobileUA = ""
    var desktopUA = ""
    val incognitoHosts = HashSet<String>()
    var settingOmni = false

    var customView: View? = null
    var customCb: WebChromeClient.CustomViewCallback? = null
    var fileCb: ValueCallback<Array<Uri>>? = null
    var pendingDownload: (() -> Unit)? = null
    var voiceTarget = "search"

    // AI durumu
    val aiMsgs = ArrayList<AiMsg>()
    var aiDialog: BottomSheetDialog? = null
    var aiCol: LinearLayout? = null
    var aiScroll: ScrollView? = null

    private var lastW = 0
    private var lastH = 0

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCb
        fileCb = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDownload?.invoke() else toast("İndirmek için depolama izni gerekli")
        pendingDownload = null
    }

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) {
                if (voiceTarget == "ai") {
                    showAi()
                    aiSend(said)
                } else {
                    closeOverlay()
                    load(tab(), said)
                }
            }
        }
    }

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        st = Store(this)
        val theme = st.str("theme", "system")
        super.onCreate(savedInstanceState)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        P.init(night, theme == "dark")
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val wic = WindowInsetsControllerCompat(window, window.decorView)
        wic.isAppearanceLightStatusBars = !night
        wic.isAppearanceLightNavigationBars = !night

        val def = WebSettings.getDefaultUserAgent(this)
        mobileUA = def.replace("; wv", "").replace(" Version/4.0", "")
        desktopUA = mobileUA
            .replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)")
            .replace(" Mobile", "")

        buildUi()
        restoreSession()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                backLogic()
            }
        })
        root.post { handleIntent(intent) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        saveSession()
        super.onPause()
    }

    override fun onDestroy() {
        for (t in tabs) {
            try {
                t.web.destroy()
            } catch (e: Exception) {
            }
        }
        wipeIncognito()
        super.onDestroy()
    }

    fun tab(): Tab = cur!!

    fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- arayüz

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(P.bg)

        main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setBackgroundColor(P.bar)

        // Üst çubuk: adres + sekme sayısı + menü
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(dp(8), dp(6), dp(2), dp(6))

        val omniWrap = LinearLayout(this)
        omniWrap.orientation = LinearLayout.HORIZONTAL
        omniWrap.gravity = Gravity.CENTER_VERTICAL
        omniWrap.background = rounded(P.field, 24)
        omniWrap.setPadding(dp(14), 0, dp(8), 0)

        lockIcon = tv("🔍", 14f)
        omni = EditText(this)
        omni.background = null
        omni.hint = "Ara veya adres yaz"
        omni.setHintTextColor(P.sub)
        omni.setTextColor(P.text)
        omni.textSize = 15f
        omni.setSingleLine()
        omni.imeOptions = EditorInfo.IME_ACTION_GO
        omni.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        omni.setSelectAllOnFocus(true)
        omni.setPadding(dp(8), 0, dp(4), 0)
        omniWrap.addView(lockIcon)
        omniWrap.addView(omni, LinearLayout.LayoutParams(0, dp(44), 1f))

        omni.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                submitOmni()
                true
            } else {
                false
            }
        }
        omni.setOnFocusChangeListener { _, f ->
            if (f) updateSuggest(omni.text.toString()) else hideSuggest()
        }
        omni.onText { updateSuggest(it) }

        tabCountTv = tv("1", 13f, P.text, true)
        tabCountTv.gravity = Gravity.CENTER
        val box = GradientDrawable()
        box.setStroke(dp(2), P.text)
        box.cornerRadius = dp(7).toFloat()
        tabCountTv.background = box
        val lpTab = LinearLayout.LayoutParams(dp(28), dp(28))
        lpTab.setMargins(dp(10), 0, dp(6), 0)
        tabCountTv.setOnClickListener { showTabs() }

        topBar.addView(omniWrap, LinearLayout.LayoutParams(0, dp(44), 1f))
        topBar.addView(tabCountTv, lpTab)
        topBar.addView(iconBtn("⋮", 22f) { showMenu() })

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.progressTintList = android.content.res.ColorStateList.valueOf(P.accent)
        progressBar.visibility = View.INVISIBLE

        // Sayfada bul çubuğu
        findBar = LinearLayout(this)
        findBar.orientation = LinearLayout.HORIZONTAL
        findBar.gravity = Gravity.CENTER_VERTICAL
        findBar.setPadding(dp(12), dp(2), dp(4), dp(2))
        findBar.visibility = View.GONE
        findInput = EditText(this)
        findInput.hint = "Sayfada bul"
        findInput.setHintTextColor(P.sub)
        findInput.setTextColor(P.text)
        findInput.setSingleLine()
        findCount = tv("", 13f, P.sub)
        findBar.addView(findInput, LinearLayout.LayoutParams(0, WC, 1f))
        findBar.addView(findCount)
        findBar.addView(iconBtn("▲", 16f) { cur?.web?.findNext(false) })
        findBar.addView(iconBtn("▼", 16f) { cur?.web?.findNext(true) })
        findBar.addView(iconBtn("✕", 16f) { closeFind() })
        findInput.onText { q ->
            val w = cur?.web
            if (w != null) {
                if (q.isEmpty()) {
                    w.clearMatches()
                    findCount.text = ""
                } else {
                    w.findAllAsync(q)
                }
            }
        }

        // Web alanı
        webContainer = FrameLayout(this)
        webContainer.setBackgroundColor(P.bg)
        webContainer.isFocusableInTouchMode = true
        startView = ScrollView(this)
        startView.setBackgroundColor(P.bg)
        startView.isFillViewport = true
        webContainer.addView(startView, FrameLayout.LayoutParams(MP, MP))
        suggestBox = LinearLayout(this)
        suggestBox.orientation = LinearLayout.VERTICAL
        suggestBox.setBackgroundColor(P.bar)
        suggestBox.elevation = dp(8).toFloat()
        suggestBox.visibility = View.GONE
        webContainer.addView(suggestBox, FrameLayout.LayoutParams(MP, WC, Gravity.TOP))

        // Alt çubuk
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        fun nav(label: String, size: Float, a: () -> Unit): TextView {
            val b = iconBtn(label, size, a)
            b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            bottom.addView(b)
            return b
        }
        btnBack = nav("◀", 18f) { cur?.web?.let { if (it.canGoBack()) it.goBack() } }
        btnFwd = nav("▶", 18f) { cur?.web?.let { if (it.canGoForward()) it.goForward() } }
        btnReload = nav("↻", 22f) { reloadOrStop() }
        btnStar = nav("☆", 22f) { toggleBookmark() }
        nav("⌂", 24f) { goHome() }

        main.addView(topBar, LinearLayout.LayoutParams(MP, WC))
        main.addView(progressBar, LinearLayout.LayoutParams(MP, dp(3)))
        main.addView(findBar, LinearLayout.LayoutParams(MP, WC))
        main.addView(webContainer, LinearLayout.LayoutParams(MP, 0, 1f))
        main.addView(divider())
        main.addView(bottom, LinearLayout.LayoutParams(MP, WC))

        overlay = FrameLayout(this)
        overlay.setBackgroundColor(P.bg)
        overlay.isClickable = true
        overlay.visibility = View.GONE

        fullscreen = FrameLayout(this)
        fullscreen.setBackgroundColor(0xFF000000.toInt())
        fullscreen.visibility = View.GONE

        // AI düğmesi (sürüklenebilir)
        fab = TextView(this)
        fab.text = "✨"
        fab.textSize = 24f
        fab.gravity = Gravity.CENTER
        fab.background = oval(P.accent)
        fab.elevation = dp(8).toFloat()
        fab.alpha = 0.95f
        fab.visibility = if (st.bool("fab_show", true)) View.VISIBLE else View.GONE
        setupFabTouch()

        root.addView(main, FrameLayout.LayoutParams(MP, MP))
        root.addView(fab, FrameLayout.LayoutParams(dp(FAB_SIZE), dp(FAB_SIZE)))
        root.addView(overlay, FrameLayout.LayoutParams(MP, MP))
        root.addView(fullscreen, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            main.setPadding(b.left, b.top, b.right, b.bottom)
            overlay.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (root.width != lastW || root.height != lastH) {
                lastW = root.width
                lastH = root.height
                positionFab()
            }
        }
    }

    // ---------------------------------------------------------------- AI düğmesi

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFabTouch() {
        var dx = 0f
        var dy = 0f
        var sx = 0f
        var sy = 0f
        var drag = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        fab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    sx = v.x
                    sy = v.y
                    drag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (!drag && (abs(mx) > slop || abs(my) > slop)) drag = true
                    if (drag) {
                        v.x = (sx + mx).coerceIn(0f, (root.width - v.width).toFloat())
                        v.y = (sy + my).coerceIn(0f, (root.height - v.height).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (drag) snapFab() else showAi()
                    true
                }
                else -> false
            }
        }
    }

    private fun snapFab() {
        val w = dp(FAB_SIZE)
        val left = fab.x + w / 2f < root.width / 2f
        val minX = dp(8).toFloat()
        val maxX = (root.width - w - dp(8)).toFloat()
        val target = if (left) minX else maxX
        fab.animate().x(target).setDuration(150).start()
        val maxY = (root.height - w).toFloat()
        st.setFloat("fab_fx", if (left) 0f else 1f)
        st.setFloat("fab_fy", if (maxY > 0f) (fab.y / maxY).coerceIn(0f, 1f) else 0.8f)
    }

    fun positionFab() {
        if (root.width == 0) return
        val w = dp(FAB_SIZE)
        val minX = dp(8).toFloat()
        val maxX = (root.width - w - dp(8)).toFloat()
        val fx = st.float("fab_fx", 1f)
        val fy = st.float("fab_fy", 0.8f)
        fab.x = minX + (maxX - minX) * fx
        fab.y = (root.height - w).toFloat() * fy
    }

    // ---------------------------------------------------------------- sekmeler

    fun createTab(incognito: Boolean): Tab {
        val w = WebView(this)
        val t = Tab(nextId++, incognito, w)
        configure(t)
        return t
    }

    fun newTab(url: String?, incognito: Boolean, select: Boolean = true, parent: Tab? = null): Tab {
        val t = createTab(incognito)
        t.parent = parent
        tabs.add(t)
        if (select) selectTab(t)
        val hp = st.str("homepage", "")
        if (url != null) {
            load(t, url)
        } else if (!incognito && hp.isNotBlank()) {
            load(t, hp)
        }
        tabCountTv.text = tabs.size.toString()
        return t
    }

    fun selectTab(t: Tab) {
        val old = cur
        if (old != null && old !== t) {
            old.web.onPause()
            webContainer.removeView(old.web)
        }
        cur = t
        if (t.web.parent == null) webContainer.addView(t.web, 0, FrameLayout.LayoutParams(MP, MP))
        t.web.onResume()
        val p = t.pending
        if (p != null) {
            t.pending = null
            t.isStart = false
            t.web.loadUrl(p)
        }
        closeFind()
        hideSuggest()
        applyStart(t)
        setOmni(if (t.isStart) "" else t.url)
        refreshNav()
    }

    fun closeTab(t: Tab) {
        val idx = tabs.indexOf(t)
        if (idx < 0) return
        val wasCur = t === cur
        tabs.removeAt(idx)
        webContainer.removeView(t.web)
        try {
            t.web.stopLoading()
            if (t.incognito) t.web.clearCache(true)
            t.web.destroy()
        } catch (e: Exception) {
        }
        if (t.incognito && tabs.none { it.incognito }) wipeIncognito()
        if (tabs.isEmpty()) {
            cur = null
            newTab(null, false)
            return
        }
        if (wasCur) {
            cur = null
            val par = t.parent
            val next = if (par != null && tabs.contains(par)) par else tabs[minOf(idx, tabs.size - 1)]
            selectTab(next)
        } else {
            refreshNav()
        }
    }

    fun applyStart(t: Tab) {
        if (t.isStart) {
            startView.visibility = View.VISIBLE
            buildStart(t)
        } else {
            startView.visibility = View.GONE
        }
    }

    fun setOmni(s: String) {
        settingOmni = true
        omni.setText(s)
        settingOmni = false
    }

    fun refreshNav() {
        val t = cur ?: return
        btnBack.alpha = if (t.web.canGoBack()) 1f else 0.35f
        btnFwd.alpha = if (t.web.canGoForward()) 1f else 0.35f
        btnReload.text = if (t.progress in 1..99) "✕" else "↻"
        btnStar.text = if (!t.isStart && st.isBookmarked(t.url)) "★" else "☆"
        lockIcon.text = when {
            t.incognito -> "🕶"
            t.isStart -> "🔍"
            t.url.startsWith("https://") -> "🔒"
            else -> "⚠️"
        }
        progressBar.progress = t.progress
        progressBar.visibility = if (t.progress in 1..99) View.VISIBLE else View.INVISIBLE
        tabCountTv.text = if (tabs.size > 99) "∞" else tabs.size.toString()
        topBar.setBackgroundColor(if (t.incognito) android.graphics.Color.parseColor(if (P.dark) "#2A2442" else "#E6E0F8") else P.bar)
    }

    // ---------------------------------------------------------------- WebView ayarı

    @SuppressLint("SetJavaScriptEnabled")
    fun configure(t: Tab) {
        val w = t.web
        w.setBackgroundColor(P.bg)
        val s = w.settings
        s.javaScriptEnabled = st.bool("js", true)
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportZoom(true)
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.textZoom = st.int("text_zoom", 100)
        t.desktop = st.bool("desktop_default", false)
        s.userAgentString = if (t.desktop) desktopUA else mobileUA
        if (t.incognito) {
            s.cacheMode = WebSettings.LOAD_NO_CACHE
            s.saveFormData = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !t.incognito)
        applyDark(t)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:") ||
                    u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("file:")
                ) return false
                openExternal(u, t)
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                t.isStart = false
                t.progress = 5
                if (url != null) {
                    t.url = url
                    if (t.incognito) rememberHost(url)
                }
                if (t === cur) {
                    applyStart(t)
                    if (!omni.hasFocus()) setOmni(url ?: "")
                    refreshNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                t.progress = 100
                if (url != null) t.url = url
                val title = view?.title
                t.title = if (!title.isNullOrBlank()) title else (url ?: "")
                if (!t.incognito && url != null) st.addHistory(t.title, url)
                if (t === cur) refreshNav()
                CookieManager.getInstance().flush()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) {
                    t.url = url
                    if (t === cur) {
                        if (!omni.hasFocus()) setOmni(url)
                        refreshNav()
                    }
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                val r = request ?: return
                if (r.isForMainFrame) {
                    val u = r.url.toString()
                    val msg = error?.description?.toString() ?: ""
                    view?.loadDataWithBaseURL(u, errorHtml(u, msg), "text/html", "UTF-8", u)
                }
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                t.progress = newProgress
                if (t === cur) refreshNav()
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) t.title = title
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                enterFullscreen(view, callback)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams!!.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                if (!isUserGesture || resultMsg == null) return false
                val nt = newTab(null, t.incognito, true, t)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = nt.web
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                closeTab(t)
            }
        }

        w.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }

        w.setOnLongClickListener {
            val r = w.hitTestResult
            val extra = r.extra
            val type = r.type
            if (extra != null && (
                    type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                        type == WebView.HitTestResult.IMAGE_TYPE ||
                        type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                    )
            ) {
                showLinkMenu(t, extra, type != WebView.HitTestResult.SRC_ANCHOR_TYPE)
                true
            } else {
                false
            }
        }

        w.setFindListener { active, count, _ ->
            if (t === cur) findCount.text = if (count == 0) "0/0" else "${active + 1}/$count"
        }
    }

    fun applyDark(t: Tab) {
        if (Build.VERSION.SDK_INT >= 33) {
            t.web.settings.isAlgorithmicDarkeningAllowed = st.bool("web_dark", false)
        }
    }

    fun applySettingsAll() {
        for (t in tabs) {
            t.web.settings.javaScriptEnabled = st.bool("js", true)
            t.web.settings.textZoom = st.int("text_zoom", 100)
            applyDark(t)
        }
        fab.visibility = if (st.bool("fab_show", true)) View.VISIBLE else View.GONE
    }

    private fun errorHtml(url: String, msg: String): String {
        fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
        val bg = if (P.dark) "#121212" else "#ffffff"
        val fg = if (P.dark) "#e8eaed" else "#202124"
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
            "<body style='font-family:sans-serif;background:$bg;color:$fg;padding:28px'>" +
            "<h2>😕 Sayfa yüklenemedi</h2><p style='word-break:break-all'>${esc(url)}</p>" +
            "<p style='opacity:.7'>${esc(msg)}</p>" +
            "<p><a href='${esc(url)}' style='color:#3B82F6'>Tekrar dene</a></p></body></html>"
    }

    private fun openExternal(u: String, t: Tab) {
        try {
            if (u.startsWith("intent:")) {
                val i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                i.addCategory(Intent.CATEGORY_BROWSABLE)
                i.component = null
                i.selector = null
                try {
                    startActivity(i)
                } catch (e: Exception) {
                    val fb = i.getStringExtra("browser_fallback_url")
                    if (!fb.isNullOrBlank()) load(t, fb)
                }
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
            }
        } catch (e: Exception) {
            toast("Bu bağlantıyı açacak uygulama yok")
        }
    }

    private fun rememberHost(url: String) {
        val h = Uri.parse(url).host
        if (h != null) incognitoHosts.add(h)
    }

    // ---------------------------------------------------------------- gezinme

    fun resolve(input: String): String {
        val s = input.trim()
        val low = s.lowercase()
        if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("about:") || low.startsWith("file://")) return s
        if (!s.contains(' ')) {
            if (Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?(/.*)?$").matches(low)) return "http://$s"
            if (Patterns.WEB_URL.matcher(s).matches()) return "https://$s"
        }
        val tmpl = when (st.str("engine", "google")) {
            "duckduckgo" -> "https://duckduckgo.com/?q="
            "bing" -> "https://www.bing.com/search?q="
            "yandex" -> "https://yandex.com.tr/search/?text="
            "brave" -> "https://search.brave.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        return tmpl + URLEncoder.encode(s, "UTF-8")
    }

    fun load(t: Tab, input: String) {
        val u = resolve(input)
        t.isStart = false
        t.pending = null
        t.url = u
        t.web.loadUrl(u)
        if (t === cur) {
            applyStart(t)
            setOmni(u)
            refreshNav()
        }
    }

    fun openUrl(url: String, inNewTab: Boolean) {
        if (inNewTab) {
            newTab(url, tab().incognito, true, tab())
        } else {
            load(tab(), url)
        }
    }

    fun submitOmni() {
        val q = omni.text.toString().trim()
        if (q.isEmpty()) return
        hideKeyboard()
        hideSuggest()
        webContainer.requestFocus()
        load(tab(), q)
    }

    fun focusOmni() {
        omni.requestFocus()
        omni.selectAll()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(omni, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(omni.windowToken, 0)
    }

    fun goHome() {
        val t = tab()
        val hp = st.str("homepage", "")
        if (hp.isBlank()) {
            t.isStart = true
            applyStart(t)
            setOmni("")
            refreshNav()
        } else {
            load(t, hp)
        }
    }

    fun reloadOrStop() {
        val t = tab()
        if (t.progress in 1..99) {
            t.web.stopLoading()
            t.progress = 100
            refreshNav()
        } else if (!t.isStart) {
            t.web.reload()
        }
    }

    fun toggleBookmark() {
        val t = tab()
        if (t.isStart) {
            toast("Önce bir sayfa aç")
            return
        }
        val added = st.toggleBookmark(t.title, t.url)
        toast(if (added) "★ Yer imi eklendi" else "Yer imi kaldırıldı")
        refreshNav()
    }

    fun setDesktop(t: Tab, on: Boolean) {
        t.desktop = on
        t.web.settings.userAgentString = if (on) desktopUA else mobileUA
        if (!t.isStart) t.web.reload()
        toast(if (on) "🖥 Masaüstü sitesi" else "📱 Mobil site")
    }

    // ---------------------------------------------------------------- bul / okuma / çeviri / yazdır / paylaş

    fun openFind() {
        if (tab().isStart) return
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    fun closeFind() {
        if (findBar.visibility == View.VISIBLE) {
            findBar.visibility = View.GONE
            findInput.setText("")
            cur?.web?.clearMatches()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(findInput.windowToken, 0)
        }
    }

    private val readerJs = """
        (function(){
          var root=document.querySelector('article')||document.querySelector('main')||document.body;
          var ps=root.querySelectorAll('p,h1,h2,h3,li');
          var out='';
          for(var i=0;i<ps.length;i++){
            var e=ps[i]; var t=(e.innerText||'').trim();
            if(e.tagName==='P'&&t.length<40)continue;
            if(t.length<2)continue;
            var tag=e.tagName.toLowerCase();
            out+='<'+tag+'>'+t.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</'+tag+'>';
          }
          if(out.length<200){window.alert('Okuma modu bu sayfada kullanılamıyor');return;}
          var dark=%DARK%;
          document.documentElement.innerHTML='<head><meta name=viewport content="width=device-width,initial-scale=1"><style>body{max-width:680px;margin:0 auto;padding:20px;font:19px/1.7 serif;background:'+(dark?'#111':'#fffdf7')+';color:'+(dark?'#ddd':'#222')+'}h1,h2,h3{font-family:sans-serif;line-height:1.3}li{margin:6px 0}</style></head><body><h1>'+document.title.replace(/</g,'&lt;')+'</h1>'+out+'</body>';
        })();
    """.trimIndent()

    fun readerMode() {
        val t = tab()
        if (t.isStart) return
        t.web.evaluateJavascript(readerJs.replace("%DARK%", P.dark.toString()), null)
    }

    fun translatePage() {
        val t = tab()
        if (t.isStart) return
        val lang = Locale.getDefault().language.ifBlank { "tr" }
        load(t, "https://translate.google.com/translate?sl=auto&tl=$lang&u=" + URLEncoder.encode(t.url, "UTF-8"))
    }

    fun printPage() {
        val t = tab()
        if (t.isStart) return
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = "Nova - " + t.title
            pm.print(name, t.web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            toast("Yazdırma başlatılamadı")
        }
    }

    fun shareText(s: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, s)
        startActivity(Intent.createChooser(i, "Paylaş"))
    }

    fun copyText(s: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Nova", s))
        toast("Kopyalandı")
    }

    fun addToHome() {
        val t = tab()
        if (t.isStart) return
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toast("Başlatıcı bu özelliği desteklemiyor")
            return
        }
        val i = Intent(this, MainActivity::class.java)
        i.action = Intent.ACTION_VIEW
        i.data = Uri.parse(t.url)
        val label = if (t.title.isBlank()) "Site" else t.title.take(20)
        val info = ShortcutInfoCompat.Builder(this, "site_" + t.url.hashCode())
            .setShortLabel(label)
            .setIcon(IconCompat.createWithResource(this, R.drawable.ic_launcher))
            .setIntent(i)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
    }

    fun siteControls() {
        val t = tab()
        if (t.isStart) return
        val host = Uri.parse(t.url).host ?: t.url
        val secure = if (t.url.startsWith("https://")) "🔒 Bağlantı güvenli (HTTPS)" else "⚠️ Bağlantı güvenli değil"
        AlertDialog.Builder(this)
            .setTitle(host)
            .setMessage(secure)
            .setPositiveButton("Bu sitenin çerezlerini sil") { _, _ ->
                clearCookiesFor(t.url)
                toast("Çerezler silindi")
            }
            .setNeutralButton("Adresi kopyala") { _, _ -> copyText(t.url) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    fun clearCookiesFor(url: String) {
        val cm = CookieManager.getInstance()
        val host = Uri.parse(url).host ?: return
        val parts = host.split(".")
        val parent = if (parts.size >= 2) parts.takeLast(2).joinToString(".") else host
        val raw = cm.getCookie(url) ?: return
        val names = raw.split(";").map { it.trim().substringBefore("=") }.filter { it.isNotEmpty() }
        val domains = listOf<String?>(null, host, ".$host", ".$parent")
        for (n in names) {
            for (d in domains) {
                val dom = if (d == null) "" else "; Domain=$d"
                cm.setCookie(url, "$n=; Max-Age=0; Path=/$dom")
            }
        }
        cm.flush()
    }

    fun wipeIncognito() {
        for (h in incognitoHosts) clearCookiesFor("https://$h")
        incognitoHosts.clear()
    }

    // ---------------------------------------------------------------- indirme

    fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Bu tür indirme desteklenmiyor")
            return
        }
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val req = DownloadManager.Request(Uri.parse(url))
                if (!mime.isNullOrBlank()) req.setMimeType(mime)
                val ck = CookieManager.getInstance().getCookie(url)
                if (!ck.isNullOrBlank()) req.addRequestHeader("Cookie", ck)
                if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                toast("⬇ İndiriliyor: $name")
            } catch (e: Exception) {
                toast("İndirme başlatılamadı")
            }
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = go
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            go()
        }
    }

    fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            toast("İndirilenler açılamadı")
        }
    }

    private fun showLinkMenu(t: Tab, url: String, isImage: Boolean) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("Yeni sekmede aç")
        acts.add { newTab(url, t.incognito, false, t); toast("Yeni sekmede açıldı") }
        if (!t.incognito) {
            labels.add("Gizli sekmede aç")
            acts.add { newTab(url, true, false, null); toast("Gizli sekmede açıldı") }
        }
        labels.add("Bağlantıyı kopyala")
        acts.add { copyText(url) }
        labels.add("Paylaş")
        acts.add { shareText(url) }
        if (isImage) {
            labels.add("Resmi indir")
            acts.add { startDownload(url, mobileUA, null, null) }
        }
        AlertDialog.Builder(this)
            .setTitle(url.take(60))
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    // ---------------------------------------------------------------- tam ekran video

    fun enterFullscreen(view: View?, cb: WebChromeClient.CustomViewCallback?) {
        if (view == null) return
        if (customView != null) {
            cb?.onCustomViewHidden()
            return
        }
        customView = view
        customCb = cb
        fullscreen.addView(view, FrameLayout.LayoutParams(MP, MP))
        fullscreen.visibility = View.VISIBLE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    fun exitFullscreen() {
        val v = customView ?: return
        fullscreen.removeView(v)
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // ---------------------------------------------------------------- menü

    fun showMenu() {
        val t = tab()
        val d = BottomSheetDialog(this)
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(P.bar)
        col.setPadding(dp(8), dp(8), dp(8), dp(24))
        sv.addView(col)

        val quick = LinearLayout(this)
        quick.orientation = LinearLayout.HORIZONTAL
        quick.gravity = Gravity.CENTER
        fun q(label: String, on: Boolean = true, a: () -> Unit) {
            val b = iconBtn(label, 20f) {
                d.dismiss()
                a()
            }
            b.alpha = if (on) 1f else 0.35f
            b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            quick.addView(b)
        }
        q("◀", t.web.canGoBack()) { t.web.goBack() }
        q("▶", t.web.canGoForward()) { t.web.goForward() }
        q(if (!t.isStart && st.isBookmarked(t.url)) "★" else "☆") { toggleBookmark() }
        q("⬇") { openDownloads() }
        q("↻") { reloadOrStop() }
        col.addView(quick)
        col.addView(divider())

        fun item(icon: String, label: String, a: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(14), dp(13), dp(14), dp(13))
            val ic = tv(icon, 20f)
            ic.gravity = Gravity.CENTER
            ic.layoutParams = LinearLayout.LayoutParams(dp(40), WC)
            r.addView(ic)
            r.addView(tv(label, 16f))
            val out = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, out, true)
            r.setBackgroundResource(out.resourceId)
            r.setOnClickListener {
                d.dismiss()
                a()
            }
            col.addView(r)
        }

        item("➕", "Yeni sekme") {
            newTab(null, false)
            focusOmni()
        }
        item("🕶", "Yeni gizli sekme") { newTab(null, true) }
        item("✨", "AI Asistan") { showAi() }
        item("🗂", "Sekmeler (${tabs.size})") { showTabs() }
        item("🕘", "Geçmiş") { showEntries(false) }
        item("⭐", "Yer imleri") { showEntries(true) }
        item("⬇", "İndirilenler") { openDownloads() }
        item("🖥", if (t.desktop) "Masaüstü sitesi  ✓" else "Masaüstü sitesi") { setDesktop(t, !t.desktop) }
        item("🔎", "Sayfada bul") { openFind() }
        item("📤", "Paylaş") { if (!t.isStart) shareText(t.url) }
        item("🌐", "Çevir") { translatePage() }
        item("📖", "Okuma modu") { readerMode() }
        item("🖨", "Yazdır / PDF kaydet") { printPage() }
        item("📲", "Ana ekrana ekle") { addToHome() }
        item("🔒", "Site kontrolleri") { siteControls() }
        item("🧹", "Tarama verilerini sil") { showClearData() }
        item("⚙️", "Ayarlar") { showSettings() }

        d.setContentView(sv)
        d.expand()
        d.show()
    }

    // ---------------------------------------------------------------- yönlendirmeler

    fun handleIntent(i: Intent?) {
        if (i == null) return
        val data = i.data
        if (data != null && (data.scheme == "http" || data.scheme == "https")) {
            val t = tab()
            closeOverlay()
            if (t.isStart) load(t, data.toString()) else newTab(data.toString(), false)
            i.data = null
            return
        }
        val cmd = i.getStringExtra("cmd") ?: return
        i.removeExtra("cmd")
        when (cmd) {
            "search" -> {
                closeOverlay()
                focusOmni()
            }
            "voice" -> startVoice("search")
            "ai" -> showAi()
            "newtab" -> {
                closeOverlay()
                newTab(null, false)
                focusOmni()
            }
            "incognito" -> {
                closeOverlay()
                newTab(null, true)
            }
            "bookmarks" -> showEntries(true)
        }
    }

    fun startVoice(target: String) {
        voiceTarget = target
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Konuş…")
        try {
            voiceLauncher.launch(i)
        } catch (e: Exception) {
            toast("Sesli giriş bu cihazda desteklenmiyor")
        }
    }

    fun backLogic() {
        if (customView != null) {
            exitFullscreen()
            return
        }
        if (overlay.visibility == View.VISIBLE) {
            closeOverlay()
            return
        }
        if (suggestBox.visibility == View.VISIBLE) {
            hideSuggest()
            hideKeyboard()
            webContainer.requestFocus()
            return
        }
        if (findBar.visibility == View.VISIBLE) {
            closeFind()
            return
        }
        val t = tab()
        val par = t.parent
        if (t.web.canGoBack()) {
            t.web.goBack()
        } else if (par != null && tabs.contains(par)) {
            closeTab(t)
        } else if (tabs.size > 1) {
            closeTab(t)
        } else {
            finish()
        }
    }

    // ---------------------------------------------------------------- oturum

    fun saveSession() {
        val normal = tabs.filter { !it.incognito }
        val items = normal.map { Pair(if (it.isStart) "" else it.url, it.title) }
        val c = cur
        val idx = if (c != null) normal.indexOf(c) else 0
        st.saveSession(items, if (idx < 0) 0 else idx)
    }

    private fun restoreSession() {
        val (items, c) = st.loadSession()
        val list = if (items.isEmpty()) listOf(Pair("", "")) else items.take(10)
        for (p in list) {
            val t = createTab(false)
            tabs.add(t)
            if (p.first.isNotBlank()) {
                t.isStart = false
                t.url = p.first
                t.title = if (p.second.isBlank()) p.first else p.second
                t.pending = p.first
            }
        }
        selectTab(tabs[c.coerceIn(0, tabs.size - 1)])
    }
}
